package br.com.estudante.teste;

//import br.com.estudante.Utils.Utils;

public class Application {
//	public static void main(String[] args) {
//		Vila vila = new Vila();
		
		
//		System.out.println(Utils.calculaComida(4));
		
		
//		System.out.println(vila);
		
//		//Aldeao que vai cultivar
//		Aldeao fazendeiro = vila.getAldeao(0);
//		Aldeao fazendeiro2 = vila.getAldeao(1);
//		Aldeao fazendeiro3 = vila.getAldeao(2);
//		
//		
//		Fazenda fazenda = vila.getFazenda(0);
//		fazendeiro.setStatus(Status.CULTIVANDO);
//		fazendeiro2.setStatus(Status.CULTIVANDO);
//		fazendeiro3.setStatus(Status.CULTIVANDO);
//		
//		fazendeiro.setFazenda(fazenda);
//		fazendeiro2.setFazenda(fazenda);
//		fazendeiro3.setFazenda(fazenda);
//		
//		fazendeiro.cultivar();
//		fazendeiro2.cultivar();
//		fazendeiro3.cultivar();
//		
//		
//		while(true) {
//			try {
//				Thread.sleep(500);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			System.out.println(vila);
//		}
//		
//		
	}
//}
