package br.com.estudante;

import java.awt.Color;

import br.com.estudante.Utils.Utils;
import br.com.estudante.tela.Principal;

public class Aldeao extends Thread {
	private String nome, tipoConstrucao; // tipoConstrução -> 0 = nada | 1 = Fazenda | 2 = Mina de Ouro | 3 = Templo | 4
	// = Maravilha
	private Enum<Status> status;
	private Fazenda fazenda;
	private MinaOuro minaOuro;
	private Prefeitura prefeitura;
	private int nivel;

	/*
	 * Constructor
	 */
	public Aldeao(String name, Prefeitura prefeitura) {
		setNome(name);
		setName("Aldeao " + getNome());
		setStatus(Status.PARADO);
		setPrefeitura(prefeitura);
		this.nivel = this.getPrefeitura().getNivelAldeoes();
		this.tipoConstrucao = ""; // Não está construindo nada
	}

	/*
	 * Run
	 */
	@Override
	public void run() {
		while (this.status != Status.SACRIFICADO) {
			this.getPrefeitura().getPrincipal().mostrarAldeao(Integer.valueOf(this.getNome()), this.getStatus());
			switch (this.status.toString()) {
			case "Cultivando":
				this.cultivar();
				break;
			case "Minerando":
				this.minerar();
				break;
			case "Construindo":
				this.construir();
				break;
			case "Orando":
				this.orar();
				break;
			}
		}
	}

	/*
	 * Getters and Setters
	 */
	public String getNome() {
		return nome;
	}

	public void setNome(String name) {
		this.nome = name;
	}

	public String getStatus() {
		return status.toString();
	}

	public void setStatus(Enum<Status> status) {
		this.status = status;
	}

	public Fazenda getFazenda() {
		return fazenda;
	}

	public void setFazenda(Fazenda fazenda) {
		if (this.fazenda != fazenda)
			this.fazenda = fazenda;
	}

	public MinaOuro getMinaOuro() {
		return minaOuro;
	}

	public void setMinaOuro(MinaOuro minaOuro) {
		if (this.minaOuro != minaOuro)
			this.minaOuro = minaOuro;
	}

	public Prefeitura getPrefeitura() {
		return prefeitura;
	}

	public void setPrefeitura(Prefeitura prefeitura) {
		this.prefeitura = prefeitura;
	}

	public int getNivel() {
		return nivel;
	}

	public void setNivel(int nivel) {
		this.nivel = nivel;
	}

	public synchronized String getTipoConstrucao() {
		return tipoConstrucao;
	}

	public synchronized void setTipoConstrucao(String tipoConstrucao) {
		this.tipoConstrucao = tipoConstrucao;
	}

	/*
	 * toString
	 */
	public String toString() {
		return "STATUS: " + getStatus();
	}

	/*
	 * Funcoes do aldeão
	 */

	public void cultivar() {
		try {
			// Sleep de uma hora para Produzir
			Thread.sleep(500);
			Integer comidaProduzida = fazenda.cultivar(this.nivel);
			// Sleep de duas horas para Transportar
			Thread.sleep(Utils.calculaTempoTransporte(this.nivel, 1000));
			prefeitura.addUnidadesComida(comidaProduzida);
			this.prefeitura.getPrincipal().mostrarComida(this.prefeitura.getUnidadesComida());

		} catch (InterruptedException e) {
			fazenda.removeFazendeiro(this);
			this.setFazenda(null);
			this.setStatus(Status.PARADO);
			this.run();
		}

	}

	public void minerar() {
		this.getPrefeitura().getPrincipal().mostrarAldeao(Integer.valueOf(this.getNome()), this.getStatus());
		try {
			// Sleep de duas horas para Produzir
			Thread.sleep(1000);
			Integer ouroProduzido = minaOuro.minerar(this.nivel);
			// Sleep de três horas para Transportar
			Thread.sleep(Utils.calculaTempoTransporte(this.nivel, 1500));
			synchronized (minaOuro) {
				prefeitura.addUnidadesOuro(ouroProduzido);
				this.prefeitura.getPrincipal().mostrarOuro(this.prefeitura.getUnidadesOuro());
			}

		} catch (InterruptedException e) {
			this.setStatus(Status.PARADO);
			this.run();
		}

	}

	public void construir() {
		this.getPrefeitura().getPrincipal().mostrarAldeao(Integer.valueOf(this.getNome()), this.getStatus());
		Vila vila = this.prefeitura.getPrincipal().getVila();
		switch (this.tipoConstrucao) {
		case "Fazenda":
			Fazenda fazenda = construirFazenda();
			if (fazenda != null) {
				vila.addFazenda(fazenda);
				this.status = Status.PARADO;
				this.tipoConstrucao = "";
			}

			break;
		case "Mina de ouro":
			MinaOuro minaOuro = construirMina();
			if (minaOuro != null) {
				vila.addMinaOuro(minaOuro);
				this.status = Status.PARADO;
				this.tipoConstrucao = "";
			}
			break;
		case "Templo":
			Templo templo = construirTemplo();
			if (templo != null && this.getStatus() != Status.PARADO.getDescription()) {
				this.getPrefeitura().getPrincipal().mostrarTemplo(templo.getNome(), Color.GRAY);
				this.getPrefeitura().getPrincipal().habilitarTemplo();
				vila.setTemplo(templo);
				this.status = Status.PARADO;
				this.tipoConstrucao = "";
			} else {
				this.prefeitura.addUnidadesComida(2000);
				this.prefeitura.addUnidadesOuro(2000);
			}
			break;
		case "Maravilha":
			if (this.getPrefeitura().getPrincipal().getVila().getMaravilha() == null) {
				Maravilha maravilha = new Maravilha(this.getPrefeitura(), this.getPrefeitura().getPrincipal());
				this.getPrefeitura().getPrincipal().getVila().setMaravilha(maravilha);
			}
			Boolean construiu = false;
			this.getPrefeitura().getPrincipal().getVila().getMaravilha().addConstrutor(this);
			while (this.getTipoConstrucao().equals("Maravilha")) {
				if (this.getPrefeitura().getUnidadesComida() >= 1 && this.getPrefeitura().getUnidadesOuro() >= 1) {
					try {
						Thread.sleep(500);
						this.getPrefeitura().addUnidadesComida(-1);
						this.getPrefeitura().addUnidadesOuro(-1);
						construiu = true;
						this.getPrefeitura().getPrincipal().getVila().getMaravilha().setQtdTijolos();
						this.getPrefeitura().getPrincipal().mostrarMaravilha(
								this.getPrefeitura().getPrincipal().getVila().getMaravilha().getQtdTijolos());
					} catch (InterruptedException e) {
						this.getPrefeitura().getPrincipal().getVila().getMaravilha().removeConstrutor(this);
						this.setStatus(Status.PARADO);
						this.tipoConstrucao = "";
						this.run();
					}
				} else if (!construiu) {
					String msg = "";

					if (this.prefeitura.getUnidadesComida() < 1 && this.prefeitura.getUnidadesOuro() >= 1)
						msg += "1 de comida";

					else if (this.prefeitura.getUnidadesComida() >= 1 && this.prefeitura.getUnidadesOuro() < 1)
						msg += "1 de ouro";

					else
						msg += "1 de comida e 1 de ouro";

					this.status = Status.PARADO;
					this.tipoConstrucao = "";

					this.prefeitura.getPrincipal().mostrarMensagemErro("Recursos insuficientes",
							"Você precisa de mais " + msg);
				} else {
					this.status = Status.PARADO;
					this.tipoConstrucao = "";
				}
			}

			this.getPrefeitura().getPrincipal().getVila().getMaravilha().removeConstrutor(this);

			break;
		}
		this.getPrefeitura().getPrincipal().mostrarAldeao(Integer.valueOf(this.getNome()), this.getStatus());
		this.prefeitura.getPrincipal().mostrarComida(this.prefeitura.getUnidadesComida());
		this.prefeitura.getPrincipal().mostrarOuro(this.prefeitura.getUnidadesOuro());
	}

	private Fazenda construirFazenda() {
		Principal principal = this.prefeitura.getPrincipal();
		if (this.prefeitura.getUnidadesComida() >= 100 && this.prefeitura.getUnidadesOuro() >= 500) {
			try {
				Thread.sleep(3000);
				this.prefeitura.addUnidadesComida(-100);
				this.prefeitura.addUnidadesOuro(-500);
				return new Fazenda(String.valueOf(principal.getVila().getQtdFazendas()), principal);
			} catch (InterruptedException e) {
				this.setStatus(Status.PARADO);
				this.run();
			}
		}

		String msg = "";

		if (this.prefeitura.getUnidadesComida() < 100 && this.prefeitura.getUnidadesOuro() >= 500)
			msg += 100 - this.prefeitura.getUnidadesComida() + " de comida";

		else if (this.prefeitura.getUnidadesComida() >= 100 && this.prefeitura.getUnidadesOuro() < 500)
			msg += 100 - this.prefeitura.getUnidadesOuro() + " de ouro";

		else
			msg += (100 - this.prefeitura.getUnidadesComida()) + " de comida e "
					+ (100 - this.prefeitura.getUnidadesOuro()) + " de ouro";

		this.prefeitura.getPrincipal().mostrarMensagemErro("Recursos insuficientes", "Você precisa de mais " + msg);
		this.status = Status.PARADO;
		this.tipoConstrucao = "";
		return null;
	}

	private MinaOuro construirMina() {
		Principal principal = this.prefeitura.getPrincipal();
		if (this.prefeitura.getUnidadesComida() >= 1000) {
			try {
				Thread.sleep(3000);
				this.prefeitura.addUnidadesComida(-100);
				this.prefeitura.addUnidadesOuro(-500);
				return new MinaOuro(String.valueOf(principal.getVila().getQtdMinasOuro()), principal);
			} catch (InterruptedException e) {
				this.setStatus(Status.PARADO);
				this.run();
			}
		}
		this.prefeitura.getPrincipal().mostrarMensagemErro("Recursos insuficientes",
				"Você precisa de mais " + (1000 - this.prefeitura.getUnidadesComida()) + " de comida");
		this.status = Status.PARADO;
		this.tipoConstrucao = "";
		return null;
	}

	private Templo construirTemplo() {
		Principal principal = this.prefeitura.getPrincipal();
		if (this.prefeitura.getUnidadesComida() >= 2000 && this.prefeitura.getUnidadesOuro() >= 2000) {
			try {
				Thread.sleep(5000); // ALTERAR
				this.prefeitura.addUnidadesComida(-2000);
				this.prefeitura.addUnidadesOuro(-2000);
				return new Templo(principal);
			} catch (InterruptedException e) {
				this.setStatus(Status.PARADO);
				this.run();
			}
		}
		String msg = "";

		if (this.prefeitura.getUnidadesComida() < 2000 && this.prefeitura.getUnidadesOuro() >= 2000)
			msg += 2000 - this.prefeitura.getUnidadesComida() + " de comida";

		else if (this.prefeitura.getUnidadesComida() >= 2000 && this.prefeitura.getUnidadesOuro() < 2000)
			msg += 2000 - this.prefeitura.getUnidadesOuro() + " de ouro";

		else
			msg += (2000 - this.prefeitura.getUnidadesComida()) + " de comida e "
					+ (2000 - this.prefeitura.getUnidadesOuro()) + " de ouro";

		this.prefeitura.getPrincipal().mostrarMensagemErro("Recursos insuficientes", "Você precisa de mais " + msg);
		return null;
	}

	public void orar() {
		this.getPrefeitura().getPrincipal().mostrarAldeao(Integer.valueOf(this.getNome()), this.getStatus());
		try {
			// Sleep de cinco horas para Produzir
			Thread.sleep(2500);
			Integer oferendaProduzida = this.getPrefeitura().getPrincipal().getVila().getTemplo().orar();
			synchronized (this.getPrefeitura().getPrincipal().getVila().getTemplo()) {
				prefeitura.addOferendasFe(oferendaProduzida);
				this.prefeitura.getPrincipal().mostrarOferendaFe(this.prefeitura.getOferendasFe());
			}
		} catch (InterruptedException e) {
			this.setStatus(Status.PARADO);
			this.run();
		}
	}

}
